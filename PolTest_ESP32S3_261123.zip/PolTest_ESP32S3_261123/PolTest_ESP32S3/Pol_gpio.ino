/*
 * PolTest ESP32 Control
 * IOs, Buttons and LED
 */

// Pins Test

 //#define BTN_1      4  // buttons, pullups
 //#define BTN_2      5
 //#define BTN_3      6
 //#define BTN_4      7

 #define PWM_RD       39  // output light sources
 #define PWM_YE       40
 #define PWM_GN       41
 #define PWM_WH       42



// +++ Init GPIO +++

void init_gpio() {
  pinMode(BTN_1, INPUT_PULLUP);  // test pin inputs, pullups
  pinMode(BTN_2, INPUT_PULLUP);
  pinMode(BTN_3, INPUT_PULLUP);
  pinMode(BTN_4, INPUT_PULLUP);

  pinMode(LED_GN, OUTPUT);  // test LED 1
  digitalWrite(LED_GN, HIGH);  // LED 1 on
  pinMode(LED_GE, OUTPUT);  // test LED 2
  digitalWrite(LED_GE, LOW);  // LED 2 off

  pinMode(PWM_RD, OUTPUT);
  pinMode(PWM_YE, OUTPUT);
  pinMode(PWM_GN, OUTPUT);
  pinMode(PWM_WH, OUTPUT);
  analogWrite(PWM_RD, 0);  // as PWM pin, set before resolution and frequency
  analogWrite(PWM_YE, 0);
  analogWrite(PWM_GN, 0);
  analogWrite(PWM_WH, 0);
  analogWriteResolution(PWM_RD, 8);  // 8 bit
  analogWriteResolution(PWM_YE, 8);
  analogWriteResolution(PWM_GN, 8);
  analogWriteResolution(PWM_WH, 8);
  analogWriteFrequency(PWM_RD, 10000);  // 10 kHz
  analogWriteFrequency(PWM_YE, 10000);
  analogWriteFrequency(PWM_GN, 10000);
  analogWriteFrequency(PWM_WH, 10000);

  lightsource[0].set = 127;
  lightsource[1].set = 127;
  lightsource[2].set = 127;
  lightsource[3].set = 127;

  rgbLedWrite(RGB_BUILTIN, 0, 0, 0);
}

// +++ Read buttons +++

void update_gpio() {



}

// +++ Button handler +++

//void update_buttons() {



//}

// +++ WS2812 Neopixel LED +++

void update_wsled(int val) {
  if (wifiset.ota) {
    rgbLedWrite(RGB_BUILTIN, 0, val, 0); // green > Upload
  } else {
    if (wifiset.con) {
      if (wifiset.ap) {
        rgbLedWrite(RGB_BUILTIN, val, 0, val); // magenta
      } else {
        rgbLedWrite(RGB_BUILTIN, 0, 0, val); // blue      
      }
    }
  }
}

// +++ Light Sources on/off+++

void update_lightsource() {
  lightsource[0].pwm = 0;
  lightsource[1].pwm = 0;
  lightsource[2].pwm = 0;
  lightsource[3].pwm = 0;
  
  if (lightset >= 0 && lightset < LEDMAX) {
    lightsource[lightset].pwm = constrain(lightsource[lightset].set, 0, 255);
  }
}

void set_lightsource(int state) {
  if (state == 0) {  
    analogWrite(PWM_RD, 0);  // dark
    analogWrite(PWM_YE, 0);
    analogWrite(PWM_GN, 0);
    analogWrite(PWM_WH, 0);
  } else {
    analogWrite(PWM_RD, lightsource[0].pwm);  // pwm
    analogWrite(PWM_YE, lightsource[1].pwm);
    analogWrite(PWM_GN, lightsource[2].pwm);
    analogWrite(PWM_WH, lightsource[3].pwm);
  }
}

