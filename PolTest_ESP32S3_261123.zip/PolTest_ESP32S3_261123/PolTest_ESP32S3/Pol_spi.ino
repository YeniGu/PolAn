/*
 * PolTest ESP32 Control
 * SPI Protocol
 */

#include <SPI.h>

#define FSCK  12
#define FMOSI 11
#define FMISO 13
#define FCSA  10  // ADS A select, optocoupler, low active
#define FCSB  9   // ADS B select, optocoupler, low active
#define FADUM 14  // ADUM enable, high active

#define SPI_CLK  1000000  // 1 MHz bus speed

#define BUFF_MAX  256

//SPIClass hspi(HSPI);

// +++ Init SPI for AVR +++

void init_spi() {
  pinMode(FCSA, OUTPUT);
  digitalWrite(FCSA, HIGH);  // disabled
  pinMode(FCSB, OUTPUT);
  digitalWrite(FCSB, HIGH);  // disabled
  pinMode(FADUM, OUTPUT);
  digitalWrite(FADUM, LOW);  // disabled

  SPI.begin(FSCK, FMISO, FMOSI, -1);
}

void spi_enable_ADUM() {
  digitalWrite(FADUM, HIGH);  // enable ADUM
  delayMicroseconds(5);
}

void spi_disable_ADUM() {
  digitalWrite(FADUM, LOW);  // disable ADUM
  delayMicroseconds(5);
}

void spi_enable_csA() {
  digitalWrite(FCSA, LOW);  // enable CS
  delayMicroseconds(20);
}

void spi_disable_csA() {
  digitalWrite(FCSA, HIGH);  // disable CS
  delayMicroseconds(50);
}

void spi_enable_csB() {
  digitalWrite(FCSB, LOW);  // enable CS
  delayMicroseconds(20);
}

void spi_disable_csB() {
  digitalWrite(FCSB, HIGH);  // disable CS
  delayMicroseconds(50);
}

bool spi_dataready() {
  return digitalRead(FMISO) == LOW;
}

// +++ Fast shift byte +++

byte spi_transfer_byte(byte data) {
  SPI.beginTransaction(SPISettings(SPI_CLK, MSBFIRST, SPI_MODE1));
//  digitalWrite(HCS, LOW);
  byte rx = SPI.transfer(data);
//  digitalWrite(HCS, HIGH);
  SPI.endTransaction();
  return rx;
}

// +++ Transfer data +++

void spi_transfer(byte spi_buf[], int len) {
  if (len >= BUFF_MAX) {
    len = BUFF_MAX;
  }
  SPI.beginTransaction(SPISettings(SPI_CLK, MSBFIRST, SPI_MODE1));
//  digitalWrite(HCS, LOW);  // enable CS
  for (int k = 0; k < len; k++) {
    spi_buf[k] = SPI.transfer(spi_buf[k]);
  }
  SPI.endTransaction();
//  digitalWrite(HCS, HIGH);  // disable CS
}


