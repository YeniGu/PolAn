/*
 * PolTest ESP32 Control
 * Buttons and menu handling
 *
 * pinMode() for the buttons is done in init_gpio().
 */

// +++ Init buttons +++

void init_buttons() {
  btnUP.cnt   = 0;  btnUP.press   = false;  btnUP.cont   = false;
  btnDOWN.cnt = 0;  btnDOWN.press = false;  btnDOWN.cont = false;
  btnMENU.cnt = 0;  btnMENU.press = false;  btnMENU.cont = false;
  btnSEL.cnt  = 0;  btnSEL.press  = false;  btnSEL.cont  = false;
}

// +++ Read buttons +++

void debounce_button(Tbutton &btn, int gpio) {
  if (digitalRead(gpio) == LOW) {  // Active LOW
    if (btn.cnt < 255) {
      btn.cnt++;
      if (btn.cnt == 4) btn.press = true;  // short pressed
      if (btn.cnt > 15) btn.cont = true;   // long pressed, repeated
    }
  } else {
    btn.cnt = 0;  // reset when released
  }
}

void update_buttons() {
  debounce_button(btnUP,   BTN_3);  // GPIO 6, up
  debounce_button(btnDOWN, BTN_1);  // GPIO 4, down
  debounce_button(btnMENU, BTN_2);  // GPIO 5, MODE
  debounce_button(btnSEL,  BTN_4);  // GPIO 7, SET
}

// +++ Button handler, called before display_draw() +++

void update_menu() {
  // MODE: next page (start screen skipped, wraps after the last page)
  if (btnMENU.press) {
    btnMENU.press = false;  // reset
    ui.menu++;
    if (ui.menu >= MN_END) ui.menu = MN_VALRAW;
    Serial.printf("MODE -> menu %d\n", ui.menu);  // debug: 1 = raw values, 2 = wifi
  }
  if (btnMENU.cont) {
    btnMENU.cont = false;  // reset, long press not used for MODE
  }

  // SET
  if (btnSEL.press) {
    btnSEL.press = false;  // reset
    Serial.println("SET pressed");
    // TODO: pause / continue measurement, or enter / confirm in settings menu
  }
  if (btnSEL.cont) {
    btnSEL.cont = false;  // reset
    // TODO: e.g. open settings menu
  }

  // UP
  if (btnUP.press) {
    btnUP.press = false;  // reset
    Serial.println("UP pressed");
    // TODO: menu up or increase value, depends on menu / submenu
  }
  if (btnUP.cont) {
    btnUP.cont = false;  // reset
    // TODO: increase value continuously
  }

  // DOWN
  if (btnDOWN.press) {
    btnDOWN.press = false;  // reset
    Serial.println("DOWN pressed");
    // TODO: menu down or decrease value, depends on menu / submenu
  }
  if (btnDOWN.cont) {
    btnDOWN.cont = false;  // reset
    // TODO: decrease value continuously
  }
}
