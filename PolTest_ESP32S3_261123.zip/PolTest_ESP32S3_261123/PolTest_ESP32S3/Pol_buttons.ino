/*
 * PolTest ESP32 Control
 * Buttons and menu handling
 *
 */

// +++ Init buttons +++

void init_buttons() {
  btnUP.cnt   = 0;  btnUP.press   = false;  btnUP.cont   = false;
  btnDOWN.cnt = 0;  btnDOWN.press = false;  btnDOWN.cont = false;
  btnMENU.cnt = 0;  btnMENU.press = false;  btnMENU.cont = false;
  btnSEL.cnt  = 0;  btnSEL.press  = false;  btnSEL.cont  = false;
}

// +++ Read buttons +++

void debounce_button(Tbutton &btn, int gpio) { //Tbutton &btn：要处理哪个按钮的结构体。注意这个 &，它表示"引用"，也就是直接操作原来那个变量
  if (digitalRead(gpio) == LOW) {  // Active LOW
    if (btn.cnt < 255) {
      btn.cnt++;
      if (btn.cnt == 4) btn.press = true;  // short pressed 计数正好等于 4（按住 80 ms）时，把 press 设为 true。
      if (btn.cnt > 15) btn.cont = true;   // long pressed, repeated 按住超过 15 次（300 ms）后，每次调用都会把 cont 设为 true。
    }
  } else {
    btn.cnt = 0;  // reset when released
  }
}

void update_buttons() {
  debounce_button(btnUP,   BTN_3);  // GPIO 6, up
  debounce_button(btnDOWN, BTN_1);  // GPIO 4, down
  debounce_button(btnMENU, BTN_2);  // GPIO 5, MODE
  debounce_button(btnSEL,  BTN_4);  // GPIO 7, SET
}

// +++ Button handler, called before display_draw() +++

void update_menu() {
  // MODE: next page (start screen skipped, wraps after the last page)
  if (btnMENU.press) { // 有"刚按下"的标记吗？
    btnMENU.press = false;  // reset
    ui.menu++;
    if (ui.menu >= MN_END) ui.menu = MN_VALRAW;
    Serial.printf("MODE -> menu %d\n", ui.menu);  // debug: 1 = raw values, 2 = wifi
  }
  if (btnMENU.cont) {  // 有"长按中"的标记吗？
    btnMENU.cont = false;  // reset, long press not used for MODE
  }

  // SET
  if (btnSEL.press) {
    btnSEL.press = false;  // reset
    Serial.println("SET pressed");
  }
  if (btnSEL.cont) {
    btnSEL.cont = false;  // reset
  }

  // UP
  if (btnUP.press) {
    btnUP.press = false;  // reset
    Serial.println("UP pressed");
  }
  if (btnUP.cont) {
    btnUP.cont = false;  // reset
  }

  // DOWN
  if (btnDOWN.press) {
    btnDOWN.press = false;  // reset
    Serial.println("DOWN pressed");
  }
  if (btnDOWN.cont) {
    btnDOWN.cont = false;  // reset
  }
}
