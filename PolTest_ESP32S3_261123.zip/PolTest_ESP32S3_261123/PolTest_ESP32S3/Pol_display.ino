/*
 * PolTest ESP32 Control
 * SSD1309 OLED Display
 */

#include <U8g2lib.h>

// Display control pins

#define DSPRES 16 //reset
#define DSPCS  3  //chip select
#define DSPDC  8  //Data/Command Selection
  // SPI pins common with ADS1220

// Display SSD1309 2.4" DIYMORE
// Display SPI, Rotate 0, Framebuffer 1024 Bytes, manual reset
U8G2_SSD1309_128X64_NONAME0_F_4W_HW_SPI display(U8G2_R0, /* cs=*/ DSPCS, /* dc=*/ DSPDC);

// Display fonts from U8G2 library

//#define FONT_BV u8g2_font_logisoso16_tr  // Big Values U+I > force monospaced
//#define FONT_ST u8g2_font_logisoso24_tf  // start title
#define FONT_SU u8g2_font_helvR14_tf  // start subtitle

//#define FONT_BU u8g2_font_helvR08_tf  // Big Values Unit
#define FONT_BU u8g2_font_helvR10_tf  // Big Values Unit
//#define FONT_BV u8g2_font_helvR14_tn  // Big Values U+I > force monospaced
#define FONT_BV u8g2_font_helvR18_tn  // Big Values U+I > force monospaced
//#define FONT_BW u8g2_font_helvR24_tn  // Big Values W > force monospaced
#define FONT_BS u8g2_font_6x12_mf  // Big Values bottom, 7x5 monospace
//#define FONT_BS u8g2_font_profont12_tf  // Big Values bottom

//#define FONT_VU u8g2_font_helvR08_tf  // Values Unit
#define FONT_VU u8g2_font_6x12_mf  // Values Unit, 7x5 monospace
//#define FONT_VV u8g2_font_helvR08_tn  // Values value > force monospaced
#define FONT_VV u8g2_font_6x12_mf  // Values value, 7x5 monospace

#define FONT_CT u8g2_font_6x12_mf  // Chart title, 7x5 monospace
#define FONT_CS u8g2_font_6x12_mf  // Chart scale, 7x5 monospace
#define FONT_CV u8g2_font_6x12_mf  // Chart value, 7x5 monospace
#define FONT_CE u8g2_font_6x12_mf  // Chart Settings, 7x5 monospace

#define BMP_WIDTH  8
#define BMP_HEIGHT 8

static unsigned char bmp_wifi[] = {0x7c, 0x82, 0x38, 0x00, 0x10, 0x00, 0x00, 0x00};  // 5 px high

// +++ Init Displays +++

void init_display() {
  pinMode(DSPRES, OUTPUT);
  pinMode(DSPCS, OUTPUT);
  pinMode(DSPDC, OUTPUT);
  delay(50);
  digitalWrite(DSPRES, LOW);  // Reset Displays
  delay(50);
  digitalWrite(DSPRES, HIGH);
  delay(50);

  display.begin();
  display.setContrast(100);  // brightness 0..255, less changes
}

void display_prepare() {
  display.setFont(FONT_CV);
  display.setFontRefHeightExtendedText();
  display.setDrawColor(1);
  display.setFontPosTop();
  display.setFontDirection(0);
}

void display_corners() {
  int xm = display.getDisplayWidth() - 1;
  int ym = display.getDisplayHeight() - 1;
  display.drawPixel(0, 0);
  display.drawPixel(0, ym);
  display.drawPixel(xm, 0);
  display.drawPixel(xm, ym);
}

// +++ IP string +++

void ipsnprintf(char *sz, size_t size, IPAddress ip) {
  snprintf(sz, size, "%u.%u.%u.%u", ip[0], ip[1], ip[2], ip[3]);
//  snprintf(sz, size, "%u.%u.%u.%u", (uint8_t)((ip >> 0) & 0xFF), (uint8_t)((ip >> 8) & 0xFF), (uint8_t)((ip >> 16) & 0xFF), (uint8_t)((ip >> 24) & 0xFF));
}

// +++ Number to string +++

void mysnprintf(char *sz, size_t size, float val, int dp = 0) {
  if (size == 0) return;
  float abs_val = fabs(val);

  if (dp <= -1 && dp >= -3) {  // without leading zero, -.9 or .9
    if (abs_val < 1.0f) {  // between -1 and 1
      char st[16];
      snprintf(st, sizeof(st), "%.*f", abs(dp), abs_val);  // Temp String positiv
      if (val < 0.0f) {  // sign if negative, even if rounding gives .000
        snprintf(sz, size, "-%s", &st[1]); // "-.9"
      } else {
        snprintf(sz, size, "%s", &st[1]);  // ".9"
      }
      return; // done for this special case
    }       

    if (dp == -1) {  // -9 -99 variable
      snprintf(sz, size, "%.0f", val);  
    } else if (dp == -2) {   // -9.9  -99  -999 variable
      if (abs_val < 10.0f) {
        snprintf(sz, size, "%.1f", val);
      } else {
        snprintf(sz, size, "%.0f", val);
      }
    } else if (dp == -3) {   // -9.99  -99.9  -999 variable
      if (abs_val < 10.0f) {
        snprintf(sz, size, "%.2f", val);
      } else if (abs_val < 100.0f) {
        snprintf(sz, size, "%.1f", val);
      } else {
        snprintf(sz, size, "%.0f", val);
      }
    }
  } else if (dp == -5) {   // -0.9  -9.9  -99.9  -999 variable, limited
    if (abs_val < 100.0f) { 
      snprintf(sz, size, "%.1f", val);  // with leading zero
    } else {
      snprintf(sz, size, "%.0f", val);
    }
  } else {
    if (dp >= 0 && dp <= 3) {
      snprintf(sz, size, "%.*f", dp, val); 
    } else {
      snprintf(sz, size, "%f", val);
    }  
  }
}

// +++ Float in String left adjust +++

void display_float_left(int xo, int yo, float val, int dp = 0) {
  char sz[16];
  mysnprintf(sz, sizeof(sz), val, dp);
  display.drawStr(xo, yo, sz);
}

// +++ Float in String right adjust +++

void display_float_right(int xo, int yo, float val, int dp = 0) {
  char sz[16];
  mysnprintf(sz, sizeof(sz), val, dp);
  display.drawStr(xo - display.getStrWidth(sz) - 1, yo, sz);
}

void display_text_right(int xo, int yo, const char *sz) {
  display.drawStr(xo - display.getStrWidth(sz) - 1, yo, sz);
}

void display_text_center(int xo, int yo, const char *sz) {
  display.drawStr(xo - display.getStrWidth(sz) / 2, yo, sz);
}

// +++ Draw Wifi icon +++

void display_draw_wifi(int xo = 120, int yo = 0) {
//  disp.setFont(FONT_CV);
  if (wifiset.con) {  // if Wifi connected
    display.setBitmapMode(1);
    display.drawXBM(xo, yo, BMP_WIDTH, BMP_HEIGHT, bmp_wifi);
  }
}

// +++ Display Start +++

void display_start() {
  display.setFont(FONT_SU);
  display_text_center(64, 10, "Pol Analyzer");
  display.setFont(FONT_BS);
  display_text_center(64, 42, VERSION);
  for (int k = 0; k < (startup / 2); k++) {
    display.drawBox(64 - 4 * k - 4, 52, 3, 8);
    display.drawBox(64 + 4 * k, 52, 3, 8);
  }
}

// +++ Display Values raw +++

void display_value_raw() {
  display.setFont(FONT_VU);
  display.drawStr(0,  0, "I1");
  display.drawStr(0, 11, "I2");
  display.drawStr(0, 22, "I3");
  display.drawStr(0, 33, "I4");
  display.drawStr(0, 44, "I5");
  display.drawStr(0, 55, "I6");

  display.setFont(FONT_VV);

  for (int i = 0; i < 6; i++) {
    display_float_right(37, i * 11, chan[i].mean, 3); 
    display_float_right(67, i * 11, chan[i].light, 3);
    display_float_right(97, i * 11, chan[i].dark, 3);
    display_float_right(127, i * 11, chan[i].count, 0);
  }
}

// +++ Display Settings Wifi +++

void display_setwifi() {
  char szip[16];
  display.setFont(FONT_CT);
  display.drawStr( 0,  0, "Set Wifi");
  display.setFont(FONT_CE);
  display.drawStr(72, 0, "RSSI");
  display_float_right(120, 0, wifiset.rssi);

  display.drawStr( 0, 14, "Mode");
  if (wifiset.ap) {
    display.drawStr(36, 14, "AP");
  } else {
    display.drawStr(36, 14, "STA");
  }
  display.drawStr( 0, 24, "Host");
  display.drawStr(36, 24, wifiset.host.c_str());
  display.drawStr( 0, 34, "SSID");
  display.drawStr(36, 34, wifiset.ssid.c_str());
  display.drawStr( 0, 44, "Pwd");
  display.drawStr(36, 44, wifiset.pwd.c_str());
  display.drawStr( 0, 54, "IP");
  ipsnprintf(szip, sizeof(szip), wifiset.ip); display.drawStr(36, 54, szip);
  // disp.setFont(FONT_CE);
  // disp.drawStr( 0, 14, "StaIP");
  // ipsnprintf(szip, sizeof(szip), wifiset.statip);  disp.drawStr(36, 14, szip);
  // disp.drawStr( 0, 24, "Smask");
  // ipsnprintf(szip, sizeof(szip), wifiset.mask);    disp.drawStr(36, 24, szip);
  // disp.drawStr( 0, 34, "DNS 1");
  // ipsnprintf(szip, sizeof(szip), wifiset.dns1);    disp.drawStr(36, 34, szip);
  // disp.drawStr( 0, 44, "DNS 2");
  // ipsnprintf(szip, sizeof(szip), wifiset.dns2);    disp.drawStr(36, 44, szip);
  // disp.drawStr( 0, 54, "Gway");
  // ipsnprintf(szip, sizeof(szip), wifiset.gateway); disp.drawStr(36, 54, szip);
}

// +++ Display Warnings / Errors +++

void display_errormsg(const char *line1, const char *line2) {
  int xm = display.getDisplayWidth() - 1;
  int ym = display.getDisplayHeight() - 1;
  int xw = 100;
  int yw = 26;
  display.setDrawColor(0);
  display.drawRBox((xm - xw) / 2, (ym - yw) / 2, xw, yw, 8);
  display.setDrawColor(1);
  display.drawRFrame((xm - xw) / 2, (ym - yw) / 2, xw, yw, 8);
  display.setFont(FONT_CE);
  display_text_center(xm / 2, ym / 2 - 11, line1);      
  display_text_center(xm / 2, ym / 2 - 1, line2);      
}

void display_errors() {
  if (error.intens > 0) {  // Error intensity
    display_errormsg("Error", "Intensity");      
  } else if (error.dark > 0) {  // Error darklevel
    display_errormsg("Error", "Darklevel");      
  } else if (error.wdt > 0) {  // Error Watchdog
    display_errormsg("Error", "SPI Timeout");      
  } else if (wifiset.cdcon > 0) {  //  Wifi connected
    display_errormsg("Wifi", "connected");      
  } else if (wifiset.cddis > 0) {  //  Wifi disconnected
    display_errormsg("Wifi", "disconnected");      
  }
}

// +++ Display direct draw OTA update +++

void display_draw_update(int state, int prog = 0) {
  display_prepare();
  if (state == OTA_ERROR) {  // message OTA Error
    display_errormsg("OTA Upload", "Error");      
  } else if (state == OTA_END) {  // message OTA Reboot
    display_errormsg("OTA Upload", "Reboot");      
  } else if (state == OTA_WRITE) {  // message OTA Upload
    char sz[20];
    snprintf(sz, sizeof(sz), "Write %d%%", prog);
    display_errormsg("OTA Upload", sz);      
  } else if (state == OTA_START) {  // message OTA Upload
    display_errormsg("OTA Upload", "Start");      
  }
  display.sendBuffer();  // 2.2 msec data via SPI
}

// +++ Draw display +++

void display_draw() {
  display.clearBuffer();  // 2 msec write data to buffer
  display_prepare();
  display_corners();

  switch(ui.menu) {
    case MN_START: 
      display_start();
      break;
    case MN_VALRAW: 
      display_value_raw();
      break;
    case MN_SETWIFI: 
      display_setwifi(); 
      break;
    // case MN_SETCAL: 
    //   display_setcal();
    //   break;
  }
//  display.drawBox(2, 2, 124, 60);

  display_errors();  // show warnings / errors
}

void display_send() {
  display.sendBuffer();  // 2.2 msec data via SPI
}
