/*
 * PolTest ESP32 Control
 * Setup
 */

// +++ Init Variables and Arrays +++

void init_prog() {
  startup = TSTARTUP;

  ui.menu = MN_START;
  ui.sel  = MS_NONE;

  

  ccal.read = true;
  ccal.write = false;

//  prefs_getdata();  // starting values Range, Mode
}

// +++ Startup and Cooldown +++

void cooldown_timer() {
  if (startup > 0) {  // 5 seconds start
    startup--;
    if (startup == 0) {
      ui.menu = MN_VALRAW;  // finish startscreen
      setup_wifi();  // Wifi settings and first connection
    }
  }  
  if (wifiset.cdcon > 0) {  // message Wifi connected
    wifiset.cdcon--;  // Cooldown
  }
}

