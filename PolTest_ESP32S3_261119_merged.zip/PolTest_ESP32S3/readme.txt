Programming in Arduino IDE

https://www.arduino.cc/en/software/

> programming is also possible in PlatformIO and VS Code, as you like

additional libraries

preferences (https://github.com/vshymanskyy/Preferences)
update (https://github.com/arduino-libraries/Arduino_ESP32_OTA)

Arduino settings

> see screenshot

to do's

device matrix
simulate test data
normalise intensitites
- two steps
  1. create difference ligth - dark > lock-in amplifier behavior
  2. normalise sample values to the reference diode value
calculating Stokes vectors from intensities
Poincare sphere
light source managament (switching red/yellow/green LED)
data export as CSV files
program security (protect upload and settings by password)

changes

05.08.26
- change webpages from strings to littleFS
- better editing of webpages and scripts
- images can be stored in littleFS and loaded into webpages

02.09.26
- improved file upload and OTA programming

12.09.26
- added Poincare sphere to the html
  - drawing actual vector
  - drawing trace of old vectors
  - rotating sphere by mouse or touch
  - simulated stokes data

> do not render images or charts at ESP32, send data to webpage and render charts and poincare sphere with JS in browser

13.09.26 (Yeni)
- translated all the comments to English

14.09.26 (Yeni)
- normalization added (signal / reference signal)

21.09.26 (Yeni)
- fixed Wifi automatic switch issue (STA -> AP)

29.10.26 (Yeni)
- added dummy data test (a rotating linear polarizer), switch: USE_DUMMY_DATA in Pol_ads1220.ino
- modified the chart scale (auto scaling)

02.11.26 (Yeni)
- CSV export works

04.11.26 (Yeni)
- settings and update page protected by password

09.11.26 (Yeni)
- solved the issue that "wifi disconnected" appears twice at the same time

11.11.26 (Yeni)
- webpage HTML comments translated

Nov 26 (Sven)
- added OLED display
- changed ADS1220 SPI from HSPI to FSPI, needed for combatibility with the display at the same bus
- adapted ADS1220 SPI to 2 ADCs and ADUM-isolated communication
- changed LED outputs to multi-LED switching and PWM-driving via analogWrite-command

19.11.26 (Yeni)
- merged Sven's version (17.11.26) and Yeni's version (11.11.26)
  - hardware related files from Sven: SPI, ADS1220, GPIO/LEDs, display, setup, main loop, config
  - added from Yeni: dummy data mode (off by default), normalization, Wifi fixes, password protection,
    CSV export, web pages (chart scaling, norm column in raw page)
  - remaining German comments translated to English
